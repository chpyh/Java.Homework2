package Семинары.Seminar6.HomeworkSolid.Draft.Model;

public class NotENewspaper<T> extends PrintedPeriodicals<T> {
    protected String date;

    public NotENewspaper(String title, int number, int year, String date, T vendorCode, T type, T id) {
        super(title, number, year, vendorCode, type, id);
        this.date = date;
    }

    public NotENewspaper() {

    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
