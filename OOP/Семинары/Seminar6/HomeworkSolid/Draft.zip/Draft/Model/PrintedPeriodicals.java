package Семинары.Seminar6.HomeworkSolid.Draft.Model;

import Семинары.Seminar6.HomeworkSolid.Model.OfficialPrintedProduct;

public class PrintedPeriodicals<T> extends OfficialPrintedProduct<T> {
    protected int number;

    public PrintedPeriodicals(String title, int number, int year, T vendorCode, T type, T id) {
        super(vendorCode, title, type, id, year);
        this.number = number;
    }

    public PrintedPeriodicals() {

    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

}
