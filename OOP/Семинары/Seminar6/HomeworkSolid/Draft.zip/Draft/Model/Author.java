package Семинары.Seminar6.HomeworkSolid.Draft.Model;

//## Принцип открытости/закрытости 
// авторы  имеют больше значение в библиотеке: оставим задел для работы с ними заранее

public class Author {
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Author(String name) {
        this.name = name;

    }

    @Override
    public String toString() {
        return name;
    }
}
