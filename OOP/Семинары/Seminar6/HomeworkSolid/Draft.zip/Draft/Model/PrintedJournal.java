package Семинары.Seminar6.HomeworkSolid.Draft.Model;

public class PrintedJournal<T> extends PrintedPeriodicals<T> {
    String month;

    public PrintedJournal(String title, int number, String month, int year, T vendorCode, T type, T id) {

    }

    public PrintedJournal() {

    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

}
