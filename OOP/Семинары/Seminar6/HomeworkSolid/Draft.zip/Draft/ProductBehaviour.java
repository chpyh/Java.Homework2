package Семинары.Seminar6.HomeworkSolid.Draft;

// Создаем интерфейс наличия продукта в фонде библиотеки. Действуем по приницпу разделения интерфейса: цифровые документы можно будет выдать
// любому желающему, поэтому для выдачи изданий пропишем другой интерфейс.
public interface ProductBehaviour {
    void setInSide();
    boolean isInSide();    
}
